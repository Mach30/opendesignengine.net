#Prompt to make really sure we want to deploy into production
puts "\n\e######################################################################"
puts " #\n # Are you REALLY sure you want to deploy to production?"
puts " #\n # Enter y/N + enter to continue\n #"
puts " ######################################################################\n"
proceed = STDIN.gets[0..0] rescue 'n'
exit unless proceed.downcase == 'y'
set :rails_env, 'production'
set :mongrel_environment, "production"
server 'opendesignengine.net', :web, :app, :db, :primary => true
