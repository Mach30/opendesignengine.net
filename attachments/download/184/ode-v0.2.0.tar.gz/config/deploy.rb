require "bundler/capistrano"

# =============================================================================
# MULTISTAGE DEPLOYMENT CONFIGUREATION
# =============================================================================

set :stages, %w(staging production)
set :default_stage, "staging"
require 'capistrano/ext/multistage'

# =============================================================================
# REQUIRED VARIABLES
# =============================================================================

# The name of your application. Used for directory and file names associated with
# the application.
set :application, "ode"
set :deploy_to,   "/opt/bitnami/apps/#{application}"
set :web_domain,  "opendesignengine.net"

# Since Bitnami puts everything in the /opt directory, we need to add environment
# variables upon deployment so the server can find the ruby and gems executables.
set :default_environment, {
  'RUBY_VERSION' => 'ruby 1.8.7',
  'GEM_HOME'     => '/opt/bitnami/ruby/lib/ruby/gems/1.8/gems',
  'GEM_PATH'     => '/opt/bitnami/ruby/lib/ruby/gems/1.8/gems',
  'BUNDLE_PATH'  => '/opt/bitnami/ruby/lib/ruby/gems/1.8/gems',
  'PATH'         => "/opt/bitnami/ruby/bin:$PATH"
}
set :ruby_home, '/opt/bitnami/ruby'

# =============================================================================
# SOURCE CONTROL SETTINGS
# =============================================================================
set :repository,  "https://opendesignengine.net/svn/ode/trunk"
set :scm, :subversion
set :scm_command, "/opt/bitnami/subversion/bin/svn" # set remote svn path
set :local_scm_command, "svn"

# =============================================================================
# OPTIONAL VARIABLES
# =============================================================================
set :use_sudo, true
set :keep_releases, 5
default_run_options[:pty] = true

# =============================================================================
# CALLBACK TASKS
# =============================================================================

# The configuration files are not stored in the repository since they contain
# passwords. Instead they are stored on the server and copied to the application
# directory upon every deployment.
after 'deploy', 'mongrel:stop', 'mongrel:start'
after "deploy:update_code", 'update_config', "deploy:migrate", "migrate_plugins", "symlink_files"

# Backup the database before any changes schema.
before "deploy:migrate", "db:dump"

desc "Copy configuration files (database.yml, email.yml, etc) to the current release"
task :update_config, :roles => [:app, :web] do
  run "cp -Rf #{shared_path}/config/* #{release_path}/config/"
end

desc "Run migrations on all the plugins"
task :migrate_plugins, :roles => :app do
  run "cd #{current_path} && bundle exec rake RAILS_ENV=production db:migrate_plugins"
end

# Creates a symbolic link to the files
task :symlink_files do
  run "ln -nfs #{shared_path}/files #{latest_release}/files"
end

# Tars the current release and archives to the shared directory
task :archive do
  name = ENV['name'].nil? ? 'ode' : ENV['name']
  archive_file = "#{archive_name(name)}.tar.gz"
  puts "archiving #{archive_file}..."
  cmd = "tar -zcvf #{shared_path}/archives/#{archive_file} --exclude=.svn ."
  run "cd #{current_path} && #{cmd}"
  puts "Archive release with #{archive_file}, copied to #{shared_path}"
  puts "Downloading #{archive_file}..."
  get "#{shared_path}/archives/#{archive_file}", "tmp/#{archive_file}"
end

# =============================================================================
# APACHE TASKS
# =============================================================================
namespace :apache do
  desc "Restart the Apache web server."
  task :restart, :roles => :web do
    sudo "/opt/bitnami/ctlscript.sh restart apache"
  end

  desc "Stop the Apache web server"
  task :stop, :roles => :web do
    sudo "/opt/bitnami/ctlscript.sh stop apache"
  end

  desc "Start the Apache web server"
  task :start, :roles => :web do
    sudo "/opt/bitnami/ctlscript.sh start apache"
  end
end

# =============================================================================
# DATABASE TASKS
# =============================================================================
namespace :db do

  desc "Restart the database server"
  task :restart, :roles => :web do
    sudo "/opt/bitnami/ctlscript.sh restart mysql"
  end

  desc "Stop the database server"
  task :stop, :roles => :web do
    sudo "/opt/bitnami/ctlscript.sh stop mysql"
  end

  desc "Restart the database server"
  task :start, :roles => :web do
    sudo "/opt/bitnami/ctlscript.sh start mysql"
  end

  desc "Backup your MySQL database to shared_path+/db_backups"
  task :dump, :roles => :db, :only => {:primary => true} do
    backup_name unless exists?(:backup_file)
    on_rollback { run "rm -f #{backup_file}" }
    run("cat #{shared_path}/config/database.yml") { |channel, stream, data| @environment_info = YAML.load(data)[rails_env] }

    dbhost = @environment_info['host']
    dbname = @environment_info['database']
    dbuser = @environment_info['username']
    dbpass = @environment_info['password']
    run "mysqldump --add-drop-table -u #{dbuser} -h #{dbhost} -p #{dbname} | gzip -c > #{backup_file}.gz" do |ch, stream, out |
      ch.send_data "#{dbpass}\n" if out=~ /^Enter password:/
    end
  end

  task :backup_name, :roles => :db, :only => { :primary => true } do
    now = Time.now
    run "mkdir -p #{shared_path}/db_backups"
    backup_time = [now.year,now.month,now.day,now.hour,now.min,now.sec].join('-')
    set :backup_file, "#{shared_path}/db_backups/#{rails_env}-snapshot-#{backup_time}.sql"
  end

end

# =============================================================================
# MONGREL CLUSTER TASKS
# =============================================================================
set(:mongrel_conf) { "#{current_path}/config/mongrel_cluster.yml" }
namespace :mongrel do
  [ :stop, :start ].each do |t|
    desc "#{t.to_s.capitalize} the mongrel appserver"
    task t, :roles => :app do
      sudo "/opt/bitnami/apps/redmine/scripts/ctl.sh #{t.to_s}"
    end
  end
end

def archive_name(name)
  @timestamp ||= Time.now.utc.strftime("%Y%m%d%H%M%S")
  name.sub('_', '.') + ".#{rails_env}.#{@timestamp}"
end
