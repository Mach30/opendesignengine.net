class AddUsersAllowPrivateProjects < ActiveRecord::Migration
  def self.up
    add_column :users, :allow_private_projects, :boolean, :default => false, :null => false
  end

  def self.down
    remove_column :users, :allow_private_projects
  end
end
